# Octopus Tactical — nRF52 (Zephyr RTOS) Watch Firmware

Real firmware source for nRF52832 / nRF52840-based watches and dev
boards. Builds with the standard Zephyr toolchain, no NDA, no vendor
SDK. This is the firmware counterpart to the Octopus OS companion app.

## Features

- BLE LE peripheral: Heart Rate Service + Battery Service + Device
  Information Service. Auto re-advertises on disconnect.
- Tactical watch face rendered into a 240x240 RGB565 framebuffer:
  time, live HR, battery, heading, BLE status, adrenaline flag.
- Compass view with sun + moon azimuth markers (NOAA solar position,
  low-precision lunar).
- Haptic Morse transmitter driving a PWM vibration motor with correct
  dit/dah/letter/word timing.
- SOS beacon: 5-second haptic countdown, auto-armed on an adrenaline
  event (HR + stress heuristic), cancellable with the button.
- Power: single periodic work item; 250ms redraw while connected,
  10s when idle, tickless kernel + system power management.

## Build

    west init -m https://github.com/zephyrproject-rtos/zephyr
    west update
    west zephyr-export
    west build -b nrf52840dk_nrf52840 octopus-nrf52
    west flash

For a custom watch board, copy `boards/nrf52840dk_nrf52840.overlay`
to a board overlay for your target and adjust the SPI panel pins,
PWM channel, and button GPIO.

## Wiring points (be honest with yourself before flashing)

- The vitals loop simulates HR. Replace it with your optical HR
  driver or feed it from a paired BLE HRS sensor.
- The fix is hardcoded to Houston. Feed GNSS output into
  `sunmoon_positions()` for correct azimuths.
- The magnetometer is not wired; the heading rotates as a demo.
- `octopus_haptics_pulse()` one-shot cutoff is left as a k_work
  chaining exercise; the Morse path is complete.

## Why not Realtek (C20 Pro)?

Realtek's RTL876x watch SDK ships only to manufacturers under NDA.
No public toolchain or flashing protocol exists, so third-party
firmware for Da Fit-class watches is not buildable outside the
vendor. nRF52 is the open hardware path.
