/* File: src/tactical.h */
#ifndef OCTOPUS_TACTICAL_H
#define OCTOPUS_TACTICAL_H

#include <stdint.h>
#include <stdbool.h>

/* Display geometry: ST7789 240x240 class. Change for your panel. */
#define FACE_W 240
#define FACE_H 240

/* Full app state. Single struct, no heap, no dynamic anything. */
enum octopus_view {
    VIEW_FACE = 0,
    VIEW_COMPASS,
    VIEW_TOOLS,
    VIEW_SOS,
    VIEW_COUNT
};

struct octopus_state {
    enum octopus_view view;

    /* face */
    uint8_t hour;
    uint8_t minute;
    uint8_t battery_pct;

    /* health */
    uint8_t heart_rate;
    uint8_t hrv_ms;
    uint8_t stress;
    bool adrenaline;

    /* compass */
    uint16_t heading_deg;
    uint16_t sun_az_deg;
    uint16_t moon_az_deg;

    /* tools */
    uint8_t flash_mode;   /* 0 off 1 solid 2 strobe 3 sos 4 red */
    bool morse_active;

    /* sos */
    int8_t sos_countdown; /* -1 idle, 0 fired, 1..5 counting */

    /* link */
    bool ble_connected;
};

extern struct octopus_state g_state;

/* ble.c */
void octopus_ble_init(void);
void octopus_ble_notify_hr(uint8_t bpm);
void octopus_ble_notify_batt(uint8_t pct);

/* display.c */
void octopus_display_init(void);
void octopus_display_draw(const struct octopus_state *s);

/* haptics.c */
int octopus_haptics_init(void);
void octopus_haptics_pulse(uint16_t duration_ms);
void octopus_haptics_morse_start(const char *message);
void octopus_haptics_morse_stop(void);

/* sunmoon.c */
void sunmoon_positions(double lat, double lon, int64_t epoch_ms,
                        uint16_t *sun_az, uint16_t *moon_az);

/* main.c */
void octopus_set_view(enum octopus_view v);
void octopus_arm_sos(void);
void octopus_cancel_sos(void);

#endif /* OCTOPUS_TACTICAL_H */
