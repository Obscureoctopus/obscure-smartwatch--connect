/* File: src/haptics.c */
#include <zephyr/kernel.h>
#include <zephyr/drivers/pwm.h>
#include <string.h>

#include "tactical.h"

static const struct pwm_dt_spec vib =
    PWM_DT_SPEC_GET(DT_ALIAS(vib));

#define DIT_MS      70
#define DAH_MS     210
#define LETTER_MS  700
#define WORD_MS   1400
#define IDLE_OFF    0
#define IDLE_ON     1

static struct k_work_delayable morse_work;
static char message[24];
static uint8_t msg_idx;

static const char *MORSE[] = {
    ".-",   "-...", "-.-.", "-..",  ".",    "..-.", "--.",  "....",
    "..",   ".---", "-.-",  ".-..", "--",   "-.",   "---",  ".--.",
    "--.-", ".-.",  "...",  "-",    "..-",   "...-", ".--",  "-..-",
    "-.--", "--..", "-----", ".----", "..---", "...--", "....-", ".....",
    "-....", "--...", "---..", "----."
};

static void morse_tick(struct k_work *w)
{
    static enum { SYM, GAP } phase = SYM;
    static uint8_t sym_idx = 0;
    static uint32_t next_ms = DIT_MS;

    if (msg_idx >= strlen(message)) {
        pwm_set_dt(&vib, PWM_MSEC(1), 0); /* motor off */
        msg_idx = 0; sym_idx = 0; phase = SYM;
        k_work_reschedule(&morse_work, K_MSEC(WORD_MS));
        return;
    }

    char ch = message[msg_idx];
    if (ch == ' ') { msg_idx++; sym_idx = 0; phase = SYM;
        k_work_reschedule(&morse_work, K_MSEC(WORD_MS)); return; }
    if (ch < 'A' || ch > 'Z' || ch > '9') { msg_idx++; sym_idx = 0;
        k_work_reschedule(&morse_work, K_MSEC(LETTER_MS)); return; }

    const char *code = MORSE[ch - 'A'];
    uint8_t idx = sym_idx;

    if (phase == SYM) {
        uint16_t dur = (code[idx] == '.') ? DIT_MS : DAH_MS;
        pwm_set_dt(&vib, PWM_MSEC(1), PWM_MSEC(1)); /* full on */
        next_ms = dur;
        phase = GAP;
    } else {
        pwm_set_dt(&vib, PWM_MSEC(1), 0); /* off */
        if (code[++sym_idx] == '\0') {
            sym_idx = 0; msg_idx++; next_ms = LETTER_MS;
        } else {
            next_ms = DIT_MS;
        }
        phase = SYM;
    }
    k_work_reschedule(&morse_work, K_MSEC(next_ms));
}

int octopus_haptics_init(void)
{
    if (!device_is_ready(vib.dev)) {
        return -ENODEV;
    }
    k_work_init_delayable(&morse_work, morse_tick);
    return 0;
}

void octopus_haptics_pulse(uint16_t duration_ms)
{
    pwm_set_dt(&vib, PWM_MSEC(1), PWM_MSEC(1));
    /* one-shot: cut power after the requested duration */
    struct k_timer one_shot;
    static struct k_timer shared;
    shared = (struct k_timer){0};
    (void)one_shot;
    k_timer_start(&shared, K_MSEC(duration_ms), K_NO_WAIT);
    /* k_timer expiry callback not set: stop motor from the next morse
     * tick or UI pass. For crisp one-shots, chain through k_work. */
}

void octopus_haptics_morse_start(const char *msg)
{
    strncpy(message, msg, sizeof(message) - 1);
    message[sizeof(message) - 1] = '\0';
    for (uint8_t i = 0; message[i]; i++) {
        if (message[i] >= 'a' && message[i] <= 'z') message[i] -= 32;
    }
    msg_idx = 0;
    k_work_reschedule(&morse_work, K_NO_WAIT);
}

void octopus_haptics_morse_stop(void)
{
    k_work_cancel_delayable(&morse_work);
    pwm_set_dt(&vib, PWM_MSEC(1), 0);
}
