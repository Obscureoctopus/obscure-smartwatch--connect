/* File: src/ble.c */
#include <zephyr/kernel.h>
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/conn.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/bluetooth/services/bas.h>
#include <zephyr/bluetooth/services/hrs.h>

#include "tactical.h"

static const struct bt_data ad[] = {
    BT_DATA_BYTES(BT_DATA_FLAGS, (BT_LE_AD_GENERAL | BT_LE_AD_NO_BREDR)),
    BT_DATA_BYTES(BT_DATA_UUID16_ALL, BT_UUID_16_ENCODE(BT_UUID_HRS_VAL),
                  BT_UUID_16_ENCODE(BT_UUID_BAS_VAL)),
    BT_DATA(BT_DATA_NAME_COMPLETE, "Octopus Tactical", 16),
};

static const struct bt_data sd[] = {
    BT_DATA(BT_DATA_NAME_COMPLETE, "Octopus Tactical", 16),
};

static void connected(struct bt_conn *conn, uint8_t err)
{
    if (err == 0) {
        g_state.ble_connected = true;
    }
}

static void disconnected(struct bt_conn *conn, uint8_t reason)
{
    g_state.ble_connected = false;
    /* Re-advertise forever; a watch that stops advertising is a brick. */
    bt_le_adv_start(BT_LE_ADV_CONN_FAST_1, ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));
}

BT_CONN_CB_DEFINE(conn_callbacks) = {
    .connected = connected,
    .disconnected = disconnected,
};

void octopus_ble_init(void)
{
    bt_enable(NULL);
    bt_le_adv_start(BT_LE_ADV_CONN_FAST_1, ad, ARRAY_SIZE(ad), sd, ARRAY_SIZE(sd));
}

void octopus_ble_notify_hr(uint8_t bpm)
{
    if (g_state.ble_connected) {
        bt_hrs_notify(bpm);
    }
}

void octopus_ble_notify_batt(uint8_t pct)
{
    if (g_state.ble_connected) {
        bt_bas_set_battery_level(pct);
    }
}
