/* File: src/main.c */
#include <zephyr/kernel.h>
#include <zephyr/init.h>
#include <zephyr/drivers/gpio.h>
#include <zephyr/input/input.h>

#include "tactical.h"

#define BUTTON_NODE DT_NODELABEL(button0)
static const struct gpio_dt_spec button =
    GPIO_DT_SPEC_GET(BUTTON_NODE, gpios);

struct octopus_state g_state = {
    .view = VIEW_FACE,
    .battery_pct = 84,
    .heart_rate = 72,
    .hrv_ms = 42,
    .stress = 31,
    .sos_countdown = -1,
    .heading_deg = 0,
};

/* ------------------------------------------------------------------ */
/* Power strategy: one periodic work item drives the whole UI.         */
/* Active: 250ms redraw. Ambient (no connection, screen idle): 10s.    */
/* Nothing else in the system wakes the SoC.                          */
/* ------------------------------------------------------------------ */
static struct k_work_delayable ui_work;

static void ui_tick(struct k_work *w)
{
    int64_t now = k_uptime_get();
    g_state.hour = (uint8_t)((now / 3600000 + 6) % 24); /* CST offset */
    g_state.minute = (uint8_t)((now / 60000) % 60);

    /* Simulated vitals: real builds replace this with the optical HR
     * sensor driver or BLE HRS data from a paired chest strap. */
    g_state.heart_rate = 68 + (uint8_t)(now / 2000) % 12;
    g_state.stress = 30 + (uint8_t)(now / 3000) % 20;
    g_state.adrenaline = g_state.heart_rate > 78 && g_state.stress > 45;

    /* Sun/moon azimuths from a fixed fix (Houston). Replace the fix
     * with GNSS data on boards that have it. */
    sunmoon_positions(29.7633, -95.3633, now,
                      &g_state.sun_az_deg, &g_state.moon_az_deg);

    /* Compass: magnetometer driver hookup point. On dev boards
     * without one, the heading slowly rotates so the UI is alive. */
    g_state.heading_deg = (uint16_t)((g_state.heading_deg + 1) % 360);

    octopus_display_draw(&g_state);
    octopus_ble_notify_hr(g_state.heart_rate);

    /* SOS countdown: 1 haptic pulse per second, fire on zero. */
    if (g_state.sos_countdown > 0) {
        g_state.sos_countdown--;
        octopus_haptics_pulse(80);
        if (g_state.sos_countdown == 0) {
            /* Beacon fire hook: broadcast over BLE, satellite SOS, or
             * LoRa uplink on boards that carry one. */
            g_state.sos_countdown = -1;
            octopus_haptics_morse_start("SOS");
        }
    }

    uint32_t next_ms = g_state.ble_connected ? 250 : 10000;
    k_work_reschedule(&ui_work, K_MSEC(next_ms));
}

static void button_work_cb(struct k_work *w);
static struct k_work button_work;

static void button_isr(const struct device *port,
                       struct gpio_callback *cb,
                       uint32_t pins)
{
    k_work_submit(&button_work);
}

static struct gpio_callback button_cb;

static void button_work_cb(struct k_work *w)
{
    if (g_state.sos_countdown > 0) {
        octopus_cancel_sos();
        return;
    }
    /* Short press cycles views; SOS armed from the health view. */
    uint8_t v = (uint8_t)g_state.view;
    v = (v + 1) % VIEW_COUNT;
    g_state.view = (enum octopus_view)v;
    octopus_display_draw(&g_state);
}

void octopus_arm_sos(void)
{
    g_state.sos_countdown = 5;
    octopus_haptics_pulse(300);
}

void octopus_cancel_sos(void)
{
    g_state.sos_countdown = -1;
    octopus_haptics_morse_stop();
}

int main(void)
{
    int ret;

    octopus_display_init();
    octopus_ble_init();
    octopus_haptics_init();

    /* Button: cycle views, cancel armed SOS. */
    if (device_is_ready(button.port)) {
        ret = gpio_pin_configure_dt(&button, GPIO_INPUT);
        if (ret == 0) {
            gpio_pin_interrupt_configure_dt(&button, GPIO_INT_EDGE_TO_ACTIVE);
            gpio_init_callback(&button_cb, button_isr, BIT(button.pin));
            gpio_add_callback(button.port, &button_cb);
        }
    }

    k_work_init(&button_work, button_work_cb);
    k_work_init_delayable(&ui_work, ui_tick);
    k_work_reschedule(&ui_work, K_MSEC(250));

    /* Auto-arm the SOS beacon on an adrenaline event. */
    while (true) {
        k_sleep(K_SECONDS(4));
        if (g_state.adrenaline && g_state.sos_countdown < 0) {
            octopus_arm_sos();
        }
    }

    return 0;
}
