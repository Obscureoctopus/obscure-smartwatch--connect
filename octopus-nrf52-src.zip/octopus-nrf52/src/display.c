/* File: src/display.c */
#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/display.h>
#include <math.h>
#include <string.h>

#include "tactical.h"

/* RGB565 color macros for the tactical palette. */
#define RGB565(r, g, b) \
    ((((r) & 0xF8) << 8) | (((g) & 0xFC) << 3) | ((b) >> 3))

#define C_BG     RGB565(0x0A, 0x0E, 0x14)
#define C_PANEL  RGB565(0x12, 0x18, 0x26)
#define C_GREEN  RGB565(0x00, 0xE5, 0xA0)
#define C_CYAN   RGB565(0x4D, 0xA3, 0xFF)
#define C_AMBER  RGB565(0xFF, 0xC8, 0x57)
#define C_RED    RGB565(0xFF, 0x4D, 0x6D)
#define C_WHITE  RGB565(0xE8, 0xED, 0xF5)
#define C_DIM    RGB565(0x8B, 0x95, 0xA8)

static const struct device *display;
static uint16_t fb[FACE_H][FACE_W]; /* 240*240*2 = 115KB: fits nRF52840 */

static void fill_circle(int cx, int cy, int r, uint16_t col)
{
    for (int y = -r; y <= r; y++) {
        for (int x = -r; x <= r; x++) {
            if (x * x + y * y <= r * r) {
                int px = cx + x, py = cy + y;
                if (px >= 0 && px < FACE_W && py >= 0 && py < FACE_H) {
                    fb[py][px] = col;
                }
            }
        }
    }
}

static void draw_ring(int cx, int cy, int r, uint16_t col)
{
    for (int y = -r; y <= r; y++) {
        for (int x = -r; x <= r; x++) {
            int d = x * x + y * y;
            if (d <= r * r && d >= (r - 2) * (r - 2)) {
                int px = cx + x, py = cy + y;
                if (px >= 0 && px < FACE_W && py >= 0 && py < FACE_H) {
                    fb[py][px] = col;
                }
            }
        }
    }
}

/* 3x5 mini pixel font: enough for HUD digits and labels. */
static const uint16_t FONT3x5[10][5] = {
    {0b111, 0b101, 0b101, 0b101, 0b111}, /* 0 */
    {0b010, 0b110, 0b010, 0b010, 0b111}, /* 1 */
    {0b111, 0b001, 0b111, 0b100, 0b111}, /* 2 */
    {0b111, 0b001, 0b111, 0b001, 0b111}, /* 3 */
    {0b101, 0b101, 0b111, 0b001, 0b001}, /* 4 */
    {0b111, 0b100, 0b111, 0b001, 0b111}, /* 5 */
    {0b111, 0b100, 0b111, 0b101, 0b111}, /* 6 */
    {0b111, 0b001, 0b001, 0b001, 0b001}, /* 7 */
    {0b111, 0b101, 0b111, 0b101, 0b111}, /* 8 */
    {0b111, 0b101, 0b111, 0b001, 0b111}, /* 9 */
};

static void draw_digit(int x, int y, uint8_t d, uint16_t col)
{
    for (int row = 0; row < 5; row++) {
        for (int colbit = 0; colbit < 3; colbit++) {
            if (FONT3x5[d % 10][row] & (1 << (2 - colbit))) {
                int px = x + colbit * 4, py = y + row * 6;
                for (int dy = 0; dy < 4; dy++)
                    for (int dx = 0; dx < 3; dx++) {
                        int fx = px + dx, fy = py + dy;
                        if (fx >= 0 && fx < FACE_W && fy >= 0 && fy < FACE_H)
                            fb[fy][fx] = col;
                    }
            }
        }
    }
}

static void draw_number(int x, int y, int value, int digits, uint16_t col)
{
    int scale = 1;
    for (int i = 0; i < digits - 1; i++) scale *= 10;
    for (int i = 0; i < digits; i++) {
        draw_digit(x + i * 16, y, (value / scale) % 10, col);
        scale /= 10;
    }
}

static void draw_face(const struct octopus_state *s)
{
    for (int y = 0; y < FACE_H; y++)
        for (int x = 0; x < FACE_W; x++)
            fb[y][x] = C_BG;

    draw_ring(120, 120, 110, C_PANEL);

    /* time HH:MM scaled big */
    draw_number(40, 90, s->hour, 2, C_GREEN);
    draw_number(110, 90, s->minute, 2, C_GREEN);

    /* complications */
    draw_number(60, 170, s->heart_rate, 3, C_RED);
    draw_number(60, 195, s->battery_pct, 2, C_CYAN);

    /* status bar */
    draw_number(60, 30, s->heading_deg, 3, C_AMBER);
    if (s->ble_connected) fill_circle(200, 34, 4, C_GREEN);
    if (s->adrenaline) fill_circle(180, 34, 4, C_RED);
}

static void draw_compass(const struct octopus_state *s)
{
    for (int y = 0; y < FACE_H; y++)
        for (int x = 0; x < FACE_W; x++)
            fb[y][x] = C_BG;

    draw_ring(120, 120, 110, C_PANEL);
    draw_ring(120, 120, 95, RGB565(0x23, 0x2D, 0x45));

    /* azimuth ring: sun amber, moon cyan, rotated by heading. */
    for (int i = 0; i < 12; i++) {
        int a = i * 30 - (s->heading_deg / 30) * 30;
        (void)a;
    }
    /* sun marker */
    int sx = 120 + 95 * sinf((s->sun_az_deg - s->heading_deg) * 3.14159f / 180.0f);
    int sy = 120 - 95 * cosf((s->sun_az_deg - s->heading_deg) * 3.14159f / 180.0f);
    fill_circle(sx, sy, 5, C_AMBER);
    /* moon marker */
    int mx = 120 + 95 * sinf((s->moon_az_deg - s->heading_deg) * 3.14159f / 180.0f);
    int my = 120 - 95 * cosf((s->moon_az_deg - s->heading_deg) * 3.14159f / 180.0f);
    fill_circle(mx, my, 4, C_CYAN);
    /* lubber line */
    for (int t = 0; t < 70; t++) fb[120 - t][120] = C_GREEN;
    fill_circle(120, 120, 3, C_GREEN);

    draw_number(70, 210, s->heading_deg, 3, C_WHITE);
}

static void draw_tools(const struct octopus_state *s)
{
    for (int y = 0; y < FACE_H; y++)
        for (int x = 0; x < FACE_W; x++)
            fb[y][x] = C_BG;

    draw_ring(120, 120, 110, C_PANEL);
    /* flash mode indicator: off/solid/strobe/sos/red */
    static uint8_t strobe;
    strobe = (uint8_t)(k_uptime_get_32() / 100);
    uint16_t flash_col = C_DIM;
    if (s->flash_mode == 1) flash_col = C_WHITE;
    else if (s->flash_mode == 2) flash_col = (strobe % 2) ? C_WHITE : C_DIM;
    else if (s->flash_mode == 3) flash_col = (strobe % 20 < 8) ? C_RED : C_DIM;
    else if (s->flash_mode == 4) flash_col = RGB565(0xFF, 0x20, 0x38);
    fill_circle(120, 80, 30, flash_col);

    if (s->morse_active) draw_number(105, 160, 1, 1, C_CYAN);
    if (s->sos_countdown > 0) draw_number(105, 30, s->sos_countdown, 1, C_RED);
}

void octopus_display_init(void)
{
    display = DEVICE_DT_GET(DT_CHOSEN(zephyr_display));
    if (!device_is_ready(display)) {
        /* Null derivative: no panel bound. Firmware keeps running headless. */
        display = NULL;
        return;
    }
}

void octopus_display_draw(const struct octopus_state *s)
{
    if (display == NULL) return;

    switch (s->view) {
    case VIEW_FACE:   draw_face(s); break;
    case VIEW_COMPASS: draw_compass(s); break;
    case VIEW_TOOLS:
    case VIEW_SOS:
    default:          draw_tools(s); break;
    }

    struct display_buffer_descriptor desc = {
        .buf_size = sizeof(fb),
        .width = FACE_W,
        .height = FACE_H,
        .pitch = FACE_W,
    };
    display_write(display, 0, 0, &desc, (const uint8_t *)fb);
}
