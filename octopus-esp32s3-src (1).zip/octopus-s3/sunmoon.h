// File: sunmoon.h — NOAA low-precision solar position + lunar azimuth
#ifndef SUNMOON_H
#define SUNMOON_H
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void sunmoon_positions(double lat, double lon, int64_t epoch_ms,
                        uint16_t *sun_az, uint16_t *moon_az);

#ifdef __cplusplus
}
#endif
#endif
