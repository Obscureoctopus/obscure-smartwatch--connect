// File: OctopusTactical.ino
// Octopus Tactical for the Waveshare ESP32-S3-Touch-AMOLED-2.06 watch.
// Arduino framework, Arduino_GFX direct rendering (no LVGL dependency).
//
// Views (tap screen or press BOOT to cycle):
//   FACE    big clock, battery %, date, status dots
//   COMPASS live gyro heading dial with sun/moon azimuth markers
//   TOOLS   flashlight (solid/strobe/SOS/red) + Morse screen-flash "SOS"
//   SOS     armed beacon, tap to disarm, fires Morse SOS pattern
//
// Build: see README.md. Produces a .bin you flash with esptool/web flasher.

#include <Wire.h>
#include <Arduino.h>
#include "pin_config.h"
#include "Arduino_GFX_Library.h"
#include "Arduino_DriveBus_Library.h"
#include "SensorPCF85063.hpp"
#include "SensorQMI8658.hpp"
#include "XPowersLib.h"
#include "HWCDC.h"
#include "sunmoon.h"

HWCDC USBSerial;

/* ---------------- display (official Waveshare demo config) ---------------- */
Arduino_DataBus *bus = new Arduino_ESP32QSPI(
    LCD_CS /* CS */, LCD_SCLK /* SCK */, LCD_SDIO0 /* SDIO0 */,
    LCD_SDIO1 /* SDIO1 */, LCD_SDIO2 /* SDIO2 */, LCD_SDIO3 /* SDIO3 */);

Arduino_GFX *gfx = new Arduino_CO5300(bus, LCD_RESET /* RST */,
                                      0 /* rotation */, LCD_WIDTH, LCD_HEIGHT,
                                      22 /* col_offset1 */,
                                      0 /* row_offset1 */,
                                      0 /* col_offset2 */,
                                      0 /* row_offset2 */);

/* RGB565 palette */
#define C_BG    RGB565(0x0A, 0x0E, 0x14)
#define C_PANEL RGB565(0x12, 0x18, 0x26)
#define C_GREEN RGB565(0x00, 0xE5, 0xA0)
#define C_CYAN  RGB565(0x4D, 0xA3, 0xFF)
#define C_AMBER RGB565(0xFF, 0xC8, 0x57)
#define C_RED   RGB565(0xFF, 0x4D, 0x6D)
#define C_WHITE RGB565(0xE8, 0xED, 0xF5)
#define C_DIM   RGB565(0x8B, 0x95, 0xA8)

/* ---------------- touch (official Waveshare pattern) ---------------- */
std::shared_ptr<Arduino_IIC_DriveBus> IIC_Bus =
    std::make_shared<Arduino_HWIIC>(IIC_SDA, IIC_SCL, &Wire);

void Arduino_IIC_Touch_Interrupt(void);

std::unique_ptr<Arduino_IIC> FT3168(new Arduino_FT3x68(
    IIC_Bus, FT3168_DEVICE_ADDRESS, DRIVEBUS_DEFAULT_VALUE,
    TP_INT, Arduino_IIC_Touch_Interrupt));

void Arduino_IIC_Touch_Interrupt(void)
{
    FT3168->IIC_Interrupt_Flag = true;
}

/* ---------------- on-chip devices ---------------- */
SensorPCF85063 rtc;   // RTC
SensorQMI8658 qmi;     // IMU
XPowersPMU power;      // AXP2101 PMIC

enum View { VIEW_FACE, VIEW_COMPASS, VIEW_TOOLS, VIEW_SOS, VIEW_COUNT };
enum FlashMode { FLASH_OFF, FLASH_SOLID, FLASH_STROBE, FLASH_SOS, FLASH_RED };

struct App {
    View view = VIEW_FACE;
    FlashMode flash = FLASH_OFF;
    bool morse_active = false;
    bool sos_armed = false;
    int8_t sos_countdown = -1; // -1 idle, 0 fired, 1..8 counting
    float heading = 0;
    uint16_t sun_az = 0, moon_az = 0;
    uint8_t battery = 100;
    // user fix: Houston default. Edit for your location.
    double lat = 29.7633, lon = -95.3633;
    uint8_t hh = 10, mm = 8, ss = 0;
    uint16_t year = 2026;
    uint8_t mon = 11, day = 5;
} app;

/* ---------------- helpers ---------------- */
static int64_t epoch_from_datetime(uint16_t y, uint8_t mo, uint8_t d,
                                   uint8_t h, uint8_t mi, uint8_t s)
{
    // days-from-civil (Howard Hinnant), UTC assumption
    int64_t yy = y - (mo <= 2);
    int64_t era = (yy >= 0 ? yy : yy - 399) / 400;
    int64_t yoe = yy - era * 400;
    int64_t doy = (153 * (mo + (mo > 2 ? -3 : 9)) + 2) / 5 + d - 1;
    int64_t doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    int64_t days = era * 146097 + doe - 719468;
    return days * 86400 + h * 3600 + mi * 60 + s;
}

static void logf_(const char *msg)
{
    USBSerial.print("[octopus] ");
    USBSerial.println(msg);
}

static void update_clock_from_rtc()
{
    RTC_DateTime dt = rtc.getDateTime();
    app.year = dt.getYear();
    app.mon = dt.getMonth();
    app.day = dt.getDay();
    app.hh = dt.getHour();
    app.mm = dt.getMinute();
    app.ss = dt.getSecond();
}

/* ---------------- draw: FACE ---------------- */
static void draw_face()
{
    gfx->fillScreen(C_BG);
    gfx->fillCircle(205, 251, 198, C_PANEL);
    gfx->setTextColor(C_GREEN);
    gfx->setTextSize(6, 8, 4);
    gfx->setCursor(90, 180);
    char t[8];
    snprintf(t, sizeof(t), "%02u:%02u", app.hh, app.mm);
    gfx->print(t);

    gfx->setTextSize(2, 3, 1);
    gfx->setTextColor(C_DIM);
    gfx->setCursor(120, 300);
    snprintf(t, sizeof(t), "%04u-%02u-%02u", app.year, app.mon, app.day);
    gfx->print(t);

    gfx->setTextColor(C_CYAN);
    gfx->setCursor(100, 360);
    gfx->print("BAT ");
    gfx->print((int)app.battery);
    gfx->print("%");

    // status dots
    gfx->fillCircle(150, 430, 6, C_GREEN); // system
    gfx->fillCircle(180, 430, 6, C_AMBER); // sun marker live
    gfx->fillCircle(210, 430, 6, C_CYAN);  // moon marker live
    gfx->fillCircle(240, 430, 6, app.flash ? C_RED : C_DIM);
}

/* ---------------- draw: COMPASS ---------------- */
static void draw_compass()
{
    const int cx = 205, cy = 251, r = 180;
    gfx->fillScreen(C_BG);
    gfx->drawCircle(cx, cy, r, C_PANEL);
    gfx->drawCircle(cx, cy, r - 28, RGB565(0x23, 0x2D, 0x45));

    for (int i = 0; i < 24; i++) {
        float a = (i * 15 - app.heading) * M_PI / 180.0f;
        bool major = (i % 6) == 0;
        float r0 = major ? r - 12 : r - 6;
        gfx->drawLine(cx + r0 * sin(a), cy - r0 * cos(a),
                      cx + r * sin(a), cy - r * cos(a),
                      major ? C_GREEN : RGB565(0x2A, 0x34, 0x50));
    }

    // sun + moon azimuth markers
    float sa = (app.sun_az - app.heading) * M_PI / 180.0f;
    gfx->fillCircle(cx + (r - 28) * sin(sa), cy - (r - 28) * cos(sa), 7, C_AMBER);
    float ma = (app.moon_az - app.heading) * M_PI / 180.0f;
    gfx->fillCircle(cx + (r - 28) * sin(ma), cy - (r - 28) * cos(ma), 6, C_CYAN);

    // lubber line
    gfx->drawLine(cx, cy, cx, cy - r + 40, C_GREEN);
    gfx->fillCircle(cx, cy, 5, C_GREEN);

    gfx->setTextColor(C_WHITE);
    gfx->setTextSize(3, 4, 2);
    gfx->setCursor(150, 470);
    gfx->print((int)(app.heading + 0.5f));
    gfx->print((char)0xF7); // degree symbol in GFX font
    gfx->setTextSize(1, 2, 0);
    gfx->setTextColor(C_AMBER);
    gfx->setCursor(60, 20);
    gfx->print("SUN ");
    gfx->print(app.sun_az);
    gfx->setTextColor(C_CYAN);
    gfx->print("  MOON ");
    gfx->print(app.moon_az);
}

/* ---------------- draw: TOOLS ---------------- */
static void draw_tools()
{
    gfx->fillScreen(C_BG);
    uint8_t flashPhase = (millis() / 100) % 2;
    uint16_t body = C_PANEL;
    switch (app.flash) {
    case FLASH_SOLID: body = C_WHITE; break;
    case FLASH_STROBE: body = flashPhase ? C_WHITE : C_PANEL; break;
    case FLASH_SOS: body = ((millis() / 2000) % 3 == 0) ? C_RED : C_PANEL; break;
    case FLASH_RED: body = RGB565(0xFF, 0x20, 0x38); break;
    default: break;
    }
    gfx->fillCircle(205, 160, 80, body);
    gfx->setTextColor(C_WHITE);
    gfx->setTextSize(2, 3, 1);
    gfx->setCursor(110, 300);
    const char *labels[] = {"LIGHT OFF", "LIGHT SOLID", "LIGHT STROBE",
                            "LIGHT SOS", "RED NVISION"};
    gfx->print(labels[app.flash]);
    gfx->setCursor(110, 370);
    gfx->setTextColor(app.morse_active ? C_CYAN : C_DIM);
    gfx->print(app.morse_active ? "MORSE: SOS .." : "MORSE: idle");
    gfx->setTextColor(C_DIM);
    gfx->setTextSize(1, 2, 0);
    gfx->setCursor(70, 470);
    gfx->print("tap: cycle light");
}

/* ---------------- draw: SOS ---------------- */
static void draw_sos()
{
    gfx->fillScreen(C_BG);
    gfx->fillCircle(205, 251, 190, C_RED);
    gfx->setTextColor(C_WHITE);
    gfx->setTextSize(3, 4, 2);
    gfx->setCursor(105, 200);
    if (app.sos_countdown > 0) {
        gfx->print("SOS ");
        gfx->print(app.sos_countdown);
    } else if (app.sos_armed) {
        gfx->print("BEACON FIRED");
    } else {
        gfx->print("TAP TO ARM");
    }
    gfx->setTextSize(1, 2, 0);
    gfx->setCursor(130, 380);
    gfx->print("tap to cycle/disarm");
}

static void draw_all()
{
    switch (app.view) {
    case VIEW_FACE:    draw_face();    break;
    case VIEW_COMPASS: draw_compass(); break;
    case VIEW_TOOLS:   draw_tools();   break;
    case VIEW_SOS:
    default:           draw_sos();    break;
    }
}

static void cycle_view()
{
    app.view = (View)(((int)app.view + 1) % VIEW_COUNT);
    if (app.view != VIEW_SOS) {
        app.sos_countdown = -1;
        app.sos_armed = false;
    }
    draw_all();
}

/* ---------------- Morse screen-flash transmitter ---------------- */
static const char *MORSE_SOS = "...---...";

static void morse_frame(uint32_t on_ms)
{
    uint32_t t0 = millis();
    gfx->fillScreen(C_WHITE);
    while (millis() - t0 < on_ms) delay(2);
    gfx->fillScreen(C_BG);
}

static void transmit_morse_sos()
{
    app.morse_active = true;
    static const uint16_t DIT = 120, DAH = 360;
    for (int rep = 0; rep < 3; rep++) {
        for (const char *p = MORSE_SOS; *p; p++) {
            morse_frame(*p == '.' ? DIT : DAH);
            delay(DIT);
        }
        delay(700);
    }
    app.morse_active = false;
}

/* ---------------- touch + button ---------------- */
static void on_tap()
{
    if (app.view == VIEW_SOS) {
        if (app.sos_countdown > 0 || app.sos_armed) {
            // disarm, then cycle on next tap
            app.sos_countdown = -1;
            app.sos_armed = false;
            draw_sos();
            return;
        }
        // arm the beacon: 8-second haptic-style countdown
        app.sos_countdown = 8;
        draw_sos();
        return;
    }
    if (app.view == VIEW_TOOLS) {
        app.flash = (FlashMode)(((int)app.flash + 1) % 5);
        draw_tools();
        return;
    }
    cycle_view();
}

/* ---------------- setup / loop ---------------- */
void setup()
{
    USBSerial.begin(115200);
    logf_("boot");

    pinMode(PIN_BOOT_BTN, INPUT_PULLUP);

    Wire.begin(IIC_SDA, IIC_SCL);

    /* display */
    if (!gfx->begin()) {
        logf_("gfx begin failed");
    }
    gfx->fillScreen(C_BG);
    gfx->setBrightness(0xD0); // CO5300 brightness reg 0x51

    /* touch */
    while (FT3168->begin() == false) {
        logf_("FT3168 init fail");
        delay(2000);
    }
    FT3168->IIC_Write_Device_State(
        FT3168->Arduino_IIC_Touch::Device::TOUCH_POWER_MODE,
        FT3168->Arduino_IIC_Touch::Device_Mode::TOUCH_POWER_MONITOR);

    /* RTC */
    if (!rtc.begin(Wire, IIC_SDA, IIC_SCL)) {
        logf_("PCF85063 not found");
    } else {
        RTC_DateTime dt = rtc.getDateTime();
        if (dt.getYear() < 2024) {
            // first boot: set RTC to build defaults so the face is sane
            rtc.setDateTime(2026, 11, 5, 10, 8, 0);
        }
        update_clock_from_rtc();
    }

    /* IMU: gyro for heading integration */
    if (!qmi.begin(Wire, QMI8658_L_SLAVE_ADDRESS, IIC_SDA, IIC_SCL)) {
        logf_("QMI8658 not found; heading simulated");
    } else {
        qmi.configGyro(SensorQMI8658::GYR_RANGE_64DPS,
                      SensorQMI8658::GYR_ODR_250Hz,
                      SensorQMI8658::LPF_MODE_0);
        qmi.enableGyroscope();
    }

    /* PMIC: battery gauge */
    if (!power.begin(Wire, AXP2101_SLAVE_ADDRESS, IIC_SDA, IIC_SCL)) {
        logf_("AXP2101 not found; battery simulated");
    } else {
        power.disableIRQ(XPOWERS_AXP2101_ALL_IRQ);
        power.clearIrqStatus();
        power.enableIRQ(XPOWERS_AXP2101_PKEY_SHORT_IRQ);
        power.enableBattDetection();
        power.enableBattVoltageMeasure();
        logf_("AXP2101 online");
    }

    draw_all();
    logf_("ready");
}

void loop()
{
    static uint32_t last_sec = 0, last_ui = 0, last_input = 0;
    static bool dimmed = false;
    static float gx = 0, gy = 0, gz = 0;

    /* 1-second tick: clock, azimuths, battery, SOS countdown */
    if (millis() - last_sec >= 1000) {
        last_sec = millis();
        update_clock_from_rtc();
        if (power.isBatteryConnect()) {
            app.battery = power.getBatteryPercent();
        }
        sunmoon_positions(app.lat, app.lon,
                          epoch_from_datetime(app.year, app.mon, app.day,
                                              app.hh, app.mm, app.ss) * 1000,
                          &app.sun_az, &app.moon_az);

        if (app.sos_countdown > 0) {
            app.sos_countdown--;
            if (app.view == VIEW_SOS) draw_sos();
            if (app.sos_countdown == 0) {
                app.sos_countdown = -1;
                app.sos_armed = true;
                transmit_morse_sos(); // beacon fired: flash SOS pattern
                draw_all();
            }
        } else if (app.view == VIEW_FACE) {
            draw_face();
        }
    }

    /* 4Hz tick: IMU heading, touch, compass redraw */
    if (millis() - last_ui >= 250) {
        last_ui = millis();
        if (qmi.getDataReady() && qmi.getGyroscope(gx, gy, gz)) {
            app.heading = fmodf(app.heading + gz * 0.25f, 360.0f); // z-axis yaw rate
            if (app.heading < 0) app.heading += 360.0f;
        } else {
            app.heading = fmodf(app.heading + 0.4f, 360.0f); // demo drift if no IMU
        }
        if (FT3168->IIC_Interrupt_Flag) {
            FT3168->IIC_Interrupt_Flag = false;
            on_tap();
        }
        if (digitalRead(PIN_BOOT_BTN) == LOW) {
            static uint32_t last_btn = 0;
            if (millis() - last_btn > 400) {
                last_btn = millis();
                on_tap();
            }
        }
        if (app.view == VIEW_COMPASS) draw_compass();
    }

    /* ambient dim: cut brightness after 20s idle, wake on any input */
    if (FT3168->IIC_Interrupt_Flag || digitalRead(PIN_BOOT_BTN) == LOW) {
        last_input = millis();
    }
    if (last_input == 0) last_input = millis();
    if (millis() - last_input > 20000) {
        if (!dimmed) {
            gfx->setBrightness(0x18);
            dimmed = true;
            last_input = millis() - 19900; // stay dim, re-arm window
        }
    } else if (dimmed) {
        gfx->setBrightness(0xD0);
        dimmed = false;
    }

    delay(20);
}
