# Octopus Tactical — Waveshare ESP32-S3-Touch-AMOLED-2.06

Tactical watch firmware for the Waveshare ESP32-S3-Touch-AMOLED-2.06
(410x502 AMOLED, ESP32-S3R8, AXP2101, PCF85063 RTC, QMI8658 IMU, FT3x68 touch).

## Files

- `OctopusTactical.ino` — main sketch (4 views: FACE, COMPASS, TOOLS, SOS)
- `pin_config.h` — official board pin map
- `sunmoon.h` / `sunmoon.cpp` — NOAA sun + low-precision moon azimuth
- `README.md` — this file

## Views

Tap the screen or press the BOOT button (GPIO0) to cycle.

1. FACE — big clock from the PCF85063 RTC, battery % from the AXP2101, date, status dots
2. COMPASS — live heading from the QMI8658 gyro (integrated), with sun (amber) and moon (cyan) azimuth markers computed from your lat/lon
3. TOOLS — flashlight modes (OFF / SOLID / STROBE / SOS / RED NV) plus Morse screen-flash transmitter
4. SOS — tap to arm an 8-second countdown beacon; when it fires, the screen flashes the Morse "SOS" pattern; tap again to disarm

Backlight auto-dims after 20 seconds of inactivity and wakes on tap or button.

Set your location in `OctopusTactical.ino` (search for `app.lat`), default is Houston, TX.

## Build (produces the .bin)

The board libraries (Arduino_GFX, Arduino_DriveBus, SensorLib, XPowersLib) are
bundled inside the official Waveshare repo at `examples/arduino/libraries/`, so
build from inside a clone of that repo so the bundled libraries resolve.

```bash
# one-time setup
git clone https://github.com/waveshareteam/ESP32-S3-Touch-AMOLED-2.06.git
cd ESP32-S3-Touch-AMOLED-2.06/examples/arduino

# put the sketch alongside the examples (adjust path to this folder)
cp -r /path/to/octopus-s3 examples/examples/OctopusTactical

# arduino-cli
arduino-cli core update-index
arduino-cli core install esp32:esp32          # ESP32 core >= 3.0
arduino-cli lib install "lvgl"                # not used by sketch but the repo libs may reference headers
arduino-cli board attachserialport            # optional

# compile: emits OctopusTactical.ino.bin
arduino-cli compile \
  --fqbn "esp32:esp32:esp32s3:FlashSize=8M,PSRAM=opi,PartitionScheme=default_8MB" \
  --build-path build \
  --libraries libraries \
  examples/OctopusTactical/OctopusTactical.ino

# resulting firmware image:
#   build/OctopusTactical.ino.bin
# plus boot files the core places in build/ (bootloader, partitions)
```

If your board revision differs, open the Arduino IDE, install the ESP32 core,
add `examples/arduino/libraries` via Sketch > Include Library > Add .ZIP/Library
(or copy the sketch into `examples/examples/`), select the ESP32S3 Dev Module
board with 8MB flash + OPI PSRAM, and Sketch > Export Compiled Binary.

## Flash

USB-CDC flash (BOOT+RST into bootloader, or `--before default_reset`):

```bash
# option A: arduino-cli directly
arduino-cli upload \
  --fqbn "esp32:esp32:esp32s3:FlashSize=8M,PSRAM=opi,PartitionScheme=default_8MB" \
  --port /dev/ttyACM0 \
  examples/OctopusTactical/OctopusTactical.ino

# option B: esptool with the artifacts from build/
esptool.py --chip esp32s3 --port /dev/ttyACM0 --baud 921600 \
  --before default_reset --after hard_reset write_flash \
  0x0 build/bootloader.bin \
  0x8000 build/partitions.bin \
  0x10000 build/OctopusTactical.ino.bin
```

On Windows the port is `COMx`; on macOS `/dev/cu.usbmodem*`.

## Unbrick / factory restore

The official repo ships the factory firmware image. Reflash it with esptool at
the offsets listed in the repo's wiki for this board:

```bash
git clone https://github.com/waveshareteam/ESP32-S3-Touch-AMOLED-2.06.git
# see the repo firmware folder + wiki flash offsets, then:
esptool.py --chip esp32s3 --port /dev/ttyACM0 write_flash 0x0 <factory_image>.bin
```

## Notes and limits

- Heading is gyro-integrated (no magnetometer on this board), so it drifts.
  Re-zero by treating the lubber line as your reference direction. A hard iron
  compass needs an external magnetometer; none is on this PCB.
- The Morse transmitter is screen-flash only; there is no vibration motor or
  buzzer wired for haptics on this dev board.
- `PIN_POWER_BTN = 46` in `pin_config.h` is unverified against the schematic;
  the physical power button is the AXP2101 PWRON line. Only the BOOT button
  (GPIO0) is used by the sketch, so it works regardless.
- Libraries are the Waveshare bundled forks; the display config (CO5300 over
  QSPI, col_offset 22, 410x502) matches their official examples exactly.
